import {Component} from 'react';
import React from 'react';
import CssFile from './CssFile.css';
import TextButton from './TextButton.jsx';
import Draggable, {DraggableCore} from 'react-draggable';
class TextField extends React.Component{
    
constructor(props){
    super(props);
    this.state={id:"defaultId"};
    this.setTextFieldId=this.setTextFieldId.bind(this);
    this.drawLines=this.drawLines.bind(this);

}
eventLogger = (e, data) => {
    console.log('Event: ', e);
    console.log('Data: ', data);
  };

setTextFieldId(e)
{
   this.setState({
       id:e.target.value,
   });
}

drawLines(domNode1,domNode2){
 console.log("TextField.jsx drawLines",domNode1,domNode2
 );
// var c = document.getElementById("myCanvas");
// var ctx = c.getContext("2d");
// ctx.beginPath();
}


render(){
        
    return(
        <Draggable
        axis="both"
        handle=".toDrag"
        defaultPosition={{x: 0, y: 0}}
        position={null}
        grid={[25, 25]}
        scale={1}
        onStart={this.handleStart}
        onDrag={this.handleDrag}
        onStop={this.handleStop}>

   <div className="textFieldDivs" id={this.props.idDiv} >
   <div className="toDrag">Drag..</div>
   <input type="text" id={this.state.id} onChange={this.setTextFieldId} placeholder="default" value={this.state.id}/>
   <TextButton  attachedTextfieldId={this.state.id} drawLinesTFComponent={this.drawLines} />
    </div>
    </Draggable>
    );
        
}

}
export default TextField; 