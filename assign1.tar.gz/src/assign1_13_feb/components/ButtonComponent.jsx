import {Component} from 'react';

import React from 'react';
import CssFile from './CssFile.css';
class ButtonComponent extends React.Component{
    
constructor(props){

    super(props);

}

render(){

    return(
        <button className="btns" id="buttoncss" name="add_element" onClick={this.props.handleClickProps}>Add Element</button>

    );

}

}
export default ButtonComponent; 