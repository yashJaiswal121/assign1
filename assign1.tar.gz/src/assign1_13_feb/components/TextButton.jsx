import {Component} from 'react';
import React from 'react';
import CssFile from './CssFile.css';
import {connect} from 'react-redux';
import ReactDOM from 'react-dom';
import { bindActionCreators } from 'redux';
import {attachAction,removeAction} from './actions/action';

class TextButton extends React.Component{
    
constructor(props){
    super(props);
    this.state={sign:"+"};

}

action1(){
    
    var id = prompt("Enter id for connection:", "");
        const obj={
            from:this.props.attachedTextfieldId,
            to:id
        };

        this.props.attachAction(obj);
        this.drawLines(obj.from,obj.to);
        console.log("action1",this.props.reduxStoreState); //shows one less than current state of redux-store
    this.setState({sign:"-"})
}



action2(){
    const obj={
        from:this.props.attachedTextfieldId,
    };
    this.props.removeAction(obj);
    this.setState({sign:"+"})
}

drawLines(id1,id2){
const domNode1 = ReactDOM.findDOMNode(document.getElementById(id1)); //important
const domNode2 = ReactDOM.findDOMNode(document.getElementById(id2)); //important
 console.log("from coor : ",domNode1.getBoundingClientRect());
console.log("to coor : ",domNode2.getBoundingClientRect());

this.props.drawLinesTFComponent(domNode1,domNode2);
 
    }

render(){

    return(
       <button type="button" id="textbutton" onClick={()=>{ this.state.sign=="+"? this.action1() :this.action2() }}>{this.state.sign}</button>
    );

}

}
function mapDispatchToProps(dispatch){ 
    return bindActionCreators({attachAction,removeAction},dispatch);  //will bind actions to the dispatch methord of redux
}
 const mapStateToProps=(state)=>{
    console.log("mapStateTo Props",state);   //shows current state of redux-store
    return {
            reduxStoreState:state,      //will give us the redux's store's state in props of this component as 'reduxStoreReducers' (do 'console.log(this.props)' to verify it)
    }
}

export default connect(mapStateToProps,mapDispatchToProps)(TextButton);