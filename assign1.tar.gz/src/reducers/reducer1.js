
import {Add_Reminder,DELETE_REMINDER} from '../constants/Reminders';


const addReminder=(text)=>{

    return {
        reminder:text,
        id:Math.random()
    }
}

const deleteReminder=(state,id)=>{
//console.log("state delReminder",state,"|id|",id);
const reminders= state.filter(reminder=> reminder.id!==id);


return reminders;
}

const masterReducer =(state=[],action)=>{

    switch(action.type)
    {
        case Add_Reminder:
        return [...state,addReminder(action.payload)];

        case DELETE_REMINDER:
            return deleteReminder(state,action.payload);

        default: return state;
    }

}

export default masterReducer;
