import React from 'react';
import ReactDOM from 'react-dom';
import FormComponent from './components/FormComponent';
import {Provider} from 'react-redux';
import {createStore} from 'redux';
import masterReducer from './reducers/reducer1';
import masterReducerOfAssign from './assign1_13_feb/components/reducers/masterReducerOfAssign';
import PageComponent from './assign1_13_feb/components/PageComponent';
//const store=createStore(masterReducer);
// ReactDOM.render(
// <Provider store={store}>
// <FormComponent/>
// </Provider>
// , document.getElementById('root'));


const store=createStore(masterReducerOfAssign);

ReactDOM.render(<Provider store={store}><PageComponent/></Provider>,document.getElementById('root'));
