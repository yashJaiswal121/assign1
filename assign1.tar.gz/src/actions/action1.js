import {Add_Reminder,DELETE_REMINDER }from '../constants/Reminders';



export const  action1Creator=(text)=>{
    const  action1={
        type:Add_Reminder,
        payload:text,
    };
    return action1;
}
export const action2Creator=(id)=>{

    const action2={
        type:DELETE_REMINDER,
        payload:id
    };
    return action2;

}