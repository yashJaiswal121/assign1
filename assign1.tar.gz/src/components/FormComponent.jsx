import React,{Component} from 'react';
import {connect} from 'react-redux';
import { bindActionCreators } from 'redux';
import {action1Creator,action2Creator} from '../actions/action1';

class FormComponent extends React.Component{
    

    state={};
    constructor(props){
        super(props);
        this.state={reminder:"",renderReminders:[]};
    }

    addReminder=(event)=>{

    //     console.log(this.state);
    //     this.props.store.dispatch(this.action1);     //wrong to dispatch actions like this...instead use 'connect' componenet and 'mapDispatchToProps'
    //  console.log( this.props.store.getState());
    
       this.props.action1Creator(this.state.reminder);
    //    console.log("this.props.reduxStoreState: " ,this.props.reduxStoreState); //this onClick func is called earlier by redux than mapStateToProps
    //     this.setState({renderReminders:this.props.reduxStoreState});
        

    }
    

    renderRemindersFunction=()=>{
        //note : calling of 'deleteReminders' onClick
           const arr=this.props.reduxStoreState?this.props.reduxStoreState:[];
           const list=<ul>{arr.map(x=><li key={x.id} ><div>{x.reminder}
           
           <div onClick={()=>this.deleteReminders(x.id)}>X</div>    
           </div></li>)}</ul>;
      return list;
    }
    
    deleteReminders(id){
        this.props.action2Creator(id);
    }


    render(){

        return(
            <div className="form-inline">
            <div className="form-group">
                    <input type="text" placeholder="helloWorld" value={this.state.reminder} onChange={(event)=>{this.setState({reminder:event.target.value})}}/>
                    <button type="buttonstate" onClick={this.addReminder}>Add Reminder</button>
                    {this.renderRemindersFunction()} 
                </div>
            
                </div>
        );

    }

}

function mapDispatchToProps(dispatch){ 
    return bindActionCreators({action1Creator,action2Creator},dispatch);  //will bind actions to the dispatch methord of redux
}
function mapStateToProps(state){
    //console.log("mapStateTo Props",state);
    return {
            reduxStoreState:state,      //will give us the redux's store's state in props of this component as 'reduxStoreReducers' (do 'console.log(this.props)' to verify it)
    }
}

export default connect(mapStateToProps,mapDispatchToProps)(FormComponent);